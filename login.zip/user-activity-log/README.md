# 🔥 ActivityPulse — Advanced User Activity Log System

A premium full-stack application for tracking user logins, logouts, and actions with real-time analytics.

## 🏗️ Tech Stack

| Layer      | Technology                          |
|------------|-------------------------------------|
| Frontend   | AngularJS 1.8 + ngRoute + ngAnimate |
| Backend    | Java Servlets (Jakarta EE / Tomcat) |
| Database   | MySQL 8.x via JDBC                  |
| Security   | BCrypt password hashing             |
| Styling    | Glassmorphism CSS + Animations      |

## 🚀 Quick Setup

### 1. Prerequisites
- Java 11+, Maven 3.8+
- Apache Tomcat 9/10
- MySQL 8.x

### 2. Database Setup
```sql
-- Run in MySQL:
SOURCE database/schema.sql;
```

### 3. Configure Database Connection
Edit `DBConnection.java`:
```java
private static final String DB_PASSWORD = "your_mysql_password";
```

### 4. Build WAR
```bash
cd user-activity-log
mvn clean package
```

### 5. Deploy to Tomcat
Copy `target/user-activity-log.war` to Tomcat's `webapps/` folder.

### 6. Access the App
Open: http://localhost:8080/user-activity-log

## 🔐 Demo Credentials (all use: `password123`)

| Username | Role  | Color  |
|----------|-------|--------|
| admin    | ADMIN | 🔴     |
| alice    | USER  | 🩵     |
| bob      | USER  | 🔵     |
| charlie  | USER  | 🟢     |
| diana    | USER  | 🟡     |

## 📡 REST API

| Method | Endpoint               | Description                  |
|--------|------------------------|------------------------------|
| POST   | /api/login             | Authenticate user            |
| GET    | /api/login             | Check current session        |
| POST   | /api/logout            | End session                  |
| GET    | /api/activities        | List logs (paginated)        |
| GET    | /api/activities/stats  | Dashboard statistics         |
| POST   | /api/activities        | Log a new action             |
| GET    | /api/users             | List users (admin only)      |

## ✨ Features

- **Real-time Activity Feed** — auto-refreshes every 10 seconds
- **Action Simulator** — test-fire custom events from the UI
- **Admin Dashboard** — see all users and their activity
- **BCrypt Security** — industry-standard password hashing
- **Session Tracking** — per-session activity correlation
- **Glassmorphism UI** — premium dark mode with neon accents
- **Pagination & Filtering** — filter by action type
- **Responsive Design** — works on all screen sizes

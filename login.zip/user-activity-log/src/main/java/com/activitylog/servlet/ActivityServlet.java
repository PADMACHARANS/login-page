package com.activitylog.servlet;

import com.activitylog.dao.ActivityLogDAO;
import com.activitylog.model.ActivityLog;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * ActivityServlet - REST endpoint for activity log operations.
 *
 * GET  /api/activities?filter=ALL&page=1&size=20  → paginated list
 * GET  /api/activities/stats                       → dashboard stats
 * POST /api/activities                             → log a new action
 */
@WebServlet("/api/activities/*")
public class ActivityServlet extends HttpServlet {

    private final ActivityLogDAO activityLogDAO = new ActivityLogDAO();
    private final Gson           gson           = new Gson();
    private static final DateTimeFormatter FMT  = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    protected void doOptions(HttpServletRequest req, HttpServletResponse res) throws IOException {
        setCorsHeaders(res);
        res.setStatus(HttpServletResponse.SC_OK);
    }

    // ── GET ────────────────────────────────────────────────────────────────
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        setCorsHeaders(res);
        res.setContentType("application/json;charset=UTF-8");
        PrintWriter out = res.getWriter();

        // Auth check
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("{\"error\":\"Unauthorized\"}");
            return;
        }

        String pathInfo = req.getPathInfo();

        // ── /api/activities/stats ──────────────────────────────────────────
        if ("/stats".equals(pathInfo)) {
            Map<String, Object> stats = activityLogDAO.getStats();
            out.print(gson.toJson(stats));
            return;
        }

        // ── /api/activities  (paginated list) ─────────────────────────────
        String filter = req.getParameter("filter");
        int    page   = parseInt(req.getParameter("page"),  1);
        int    size   = parseInt(req.getParameter("size"),  20);
        int    offset = (page - 1) * size;

        // Non-admin users can only see their own logs
        int    userId = (int) session.getAttribute("userId");
        String role   = (String) session.getAttribute("role");

        List<ActivityLog> logs;
        int total;

        if ("ADMIN".equals(role)) {
            logs  = activityLogDAO.findAll(filter, size, offset);
            total = activityLogDAO.countAll(filter);
        } else {
            logs  = activityLogDAO.findByUser(userId, size);
            total = logs.size();
        }

        // Serialize with formatted dates
        List<Map<String, Object>> items = new ArrayList<>();
        for (ActivityLog al : logs) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id",          al.getId());
            m.put("userId",      al.getUserId());
            m.put("username",    al.getUsername());
            m.put("fullName",    al.getFullName());
            m.put("avatarColor", al.getAvatarColor());
            m.put("actionType",  al.getActionType().name());
            m.put("description", al.getDescription());
            m.put("ipAddress",   al.getIpAddress());
            m.put("sessionId",   al.getSessionId());
            m.put("icon",        al.getIcon());
            m.put("createdAt",   al.getCreatedAt() != null ? al.getCreatedAt().format(FMT) : null);
            items.add(m);
        }

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("logs",       items);
        response.put("total",      total);
        response.put("page",       page);
        response.put("size",       size);
        response.put("totalPages", (int) Math.ceil((double) total / size));

        out.print(gson.toJson(response));
    }

    // ── POST: log an action ────────────────────────────────────────────────
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        setCorsHeaders(res);
        res.setContentType("application/json;charset=UTF-8");
        PrintWriter out = res.getWriter();

        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("{\"error\":\"Unauthorized\"}");
            return;
        }

        try {
            int    userId = (int)    session.getAttribute("userId");
            String sid    = session.getId();

            JsonObject body   = gson.fromJson(req.getReader(), JsonObject.class);
            String description = body.has("description") ? body.get("description").getAsString() : "User action";
            String actionTypeStr = body.has("actionType") ? body.get("actionType").getAsString() : "ACTION";

            ActivityLog.ActionType type;
            try {
                type = ActivityLog.ActionType.valueOf(actionTypeStr.toUpperCase());
            } catch (IllegalArgumentException e) {
                type = ActivityLog.ActionType.ACTION;
            }

            ActivityLog log = new ActivityLog(userId, type, description, getClientIP(req));
            log.setUserAgent(req.getHeader("User-Agent"));
            log.setSessionId(sid);

            boolean ok = activityLogDAO.insert(log);
            if (ok) {
                out.print("{\"success\":true,\"message\":\"Activity logged\"}");
            } else {
                res.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                out.print("{\"success\":false,\"message\":\"Failed to log activity\"}");
            }
        } catch (Exception e) {
            res.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────
    private int parseInt(String val, int defaultVal) {
        try { return Integer.parseInt(val); }
        catch (Exception e) { return defaultVal; }
    }

    private String getClientIP(HttpServletRequest req) {
        String xf = req.getHeader("X-Forwarded-For");
        return (xf != null && !xf.isEmpty()) ? xf.split(",")[0].trim() : req.getRemoteAddr();
    }

    private void setCorsHeaders(HttpServletResponse res) {
        res.setHeader("Access-Control-Allow-Origin",  "*");
        res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type");
        res.setHeader("Access-Control-Allow-Credentials", "true");
    }
}

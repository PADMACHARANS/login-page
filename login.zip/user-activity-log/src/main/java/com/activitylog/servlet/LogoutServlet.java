package com.activitylog.servlet;

import com.activitylog.dao.ActivityLogDAO;
import com.activitylog.model.ActivityLog;
import com.google.gson.Gson;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * LogoutServlet - Ends the user session.
 * POST /api/logout → logs LOGOUT event and invalidates session.
 */
@WebServlet("/api/logout")
public class LogoutServlet extends HttpServlet {

    private final ActivityLogDAO activityLogDAO = new ActivityLogDAO();
    private final Gson           gson           = new Gson();

    @Override
    protected void doOptions(HttpServletRequest req, HttpServletResponse res) throws IOException {
        setCorsHeaders(res);
        res.setStatus(HttpServletResponse.SC_OK);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        setCorsHeaders(res);
        res.setContentType("application/json;charset=UTF-8");
        PrintWriter out = res.getWriter();

        HttpSession session = req.getSession(false);

        if (session != null && session.getAttribute("userId") != null) {
            int    userId   = (int)    session.getAttribute("userId");
            String fullName = (String) session.getAttribute("username");
            String sessionId = session.getId();

            // Log LOGOUT event BEFORE invalidating
            ActivityLog logoutLog = new ActivityLog(
                    userId,
                    ActivityLog.ActionType.LOGOUT,
                    fullName + " logged out successfully",
                    getClientIP(req)
            );
            logoutLog.setUserAgent(req.getHeader("User-Agent"));
            logoutLog.setSessionId(sessionId);
            activityLogDAO.insert(logoutLog);

            session.invalidate();
            out.print("{\"success\":true,\"message\":\"Logged out successfully\"}");
        } else {
            res.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"success\":false,\"message\":\"No active session\"}");
        }
    }

    private String getClientIP(HttpServletRequest req) {
        String xf = req.getHeader("X-Forwarded-For");
        return (xf != null && !xf.isEmpty()) ? xf.split(",")[0].trim() : req.getRemoteAddr();
    }

    private void setCorsHeaders(HttpServletResponse res) {
        res.setHeader("Access-Control-Allow-Origin",  "*");
        res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type");
        res.setHeader("Access-Control-Allow-Credentials", "true");
    }
}

package com.activitylog.servlet;

import com.activitylog.dao.ActivityLogDAO;
import com.activitylog.dao.UserDAO;
import com.activitylog.model.ActivityLog;
import com.activitylog.model.User;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.mindrot.jbcrypt.BCrypt;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * LoginServlet - Handles user authentication.
 * POST /api/login  → validates credentials, creates session, logs LOGIN event.
 * GET  /api/login  → returns current session user info.
 */
@WebServlet("/api/login")
public class LoginServlet extends HttpServlet {

    private final UserDAO        userDAO        = new UserDAO();
    private final ActivityLogDAO activityLogDAO = new ActivityLogDAO();
    private final Gson           gson           = new Gson();

    @Override
    protected void doOptions(HttpServletRequest req, HttpServletResponse res) throws IOException {
        setCorsHeaders(res);
        res.setStatus(HttpServletResponse.SC_OK);
    }

    // ── GET: check current session ─────────────────────────────────────────
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        setCorsHeaders(res);
        res.setContentType("application/json;charset=UTF-8");

        HttpSession session = req.getSession(false);
        PrintWriter out = res.getWriter();

        if (session != null && session.getAttribute("userId") != null) {
            int userId = (int) session.getAttribute("userId");
            User user  = userDAO.findById(userId);
            if (user != null) {
                Map<String, Object> resp = buildUserResponse(user, true);
                out.print(gson.toJson(resp));
                return;
            }
        }

        res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        out.print("{\"authenticated\":false,\"message\":\"No active session\"}");
    }

    // ── POST: authenticate ─────────────────────────────────────────────────
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        setCorsHeaders(res);
        res.setContentType("application/json;charset=UTF-8");
        PrintWriter out = res.getWriter();

        try {
            JsonObject body   = gson.fromJson(req.getReader(), JsonObject.class);
            String username   = body.get("username").getAsString().trim().toLowerCase();
            String password   = body.get("password").getAsString();

            User user = userDAO.findByUsername(username);

            // ── Failed login ───────────────────────────────────────────────
            if (user == null || !BCrypt.checkpw(password, user.getPasswordHash())) {
                if (user != null) {
                    ActivityLog failLog = new ActivityLog(
                            user.getId(),
                            ActivityLog.ActionType.FAILED_LOGIN,
                            "Failed login attempt — incorrect password",
                            getClientIP(req)
                    );
                    failLog.setUserAgent(req.getHeader("User-Agent"));
                    activityLogDAO.insert(failLog);
                }
                res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                out.print("{\"success\":false,\"message\":\"Invalid username or password\"}");
                return;
            }

            // ── Success ────────────────────────────────────────────────────
            HttpSession session = req.getSession(true);
            session.setAttribute("userId",   user.getId());
            session.setAttribute("username", user.getUsername());
            session.setAttribute("role",     user.getRole());
            session.setMaxInactiveInterval(3600); // 1 hour

            userDAO.updateLastLogin(user.getId());

            // Log LOGIN event
            ActivityLog loginLog = new ActivityLog(
                    user.getId(),
                    ActivityLog.ActionType.LOGIN,
                    user.getFullName() + " logged in successfully",
                    getClientIP(req)
            );
            loginLog.setUserAgent(req.getHeader("User-Agent"));
            loginLog.setSessionId(session.getId());
            activityLogDAO.insert(loginLog);

            out.print(gson.toJson(buildUserResponse(user, true)));

        } catch (Exception e) {
            res.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"success\":false,\"message\":\"Server error: " + e.getMessage() + "\"}");
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────
    private Map<String, Object> buildUserResponse(User user, boolean success) {
        Map<String, Object> resp = new HashMap<>();
        resp.put("success",       success);
        resp.put("authenticated", true);
        resp.put("id",            user.getId());
        resp.put("username",      user.getUsername());
        resp.put("email",         user.getEmail());
        resp.put("fullName",      user.getFullName());
        resp.put("role",          user.getRole());
        resp.put("avatarColor",   user.getAvatarColor());
        resp.put("initials",      user.getInitials());
        resp.put("lastLogin",     user.getLastLogin() != null ? user.getLastLogin().toString() : null);
        return resp;
    }

    private String getClientIP(HttpServletRequest req) {
        String xf = req.getHeader("X-Forwarded-For");
        return (xf != null && !xf.isEmpty()) ? xf.split(",")[0].trim() : req.getRemoteAddr();
    }

    private void setCorsHeaders(HttpServletResponse res) {
        res.setHeader("Access-Control-Allow-Origin",  "*");
        res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type");
        res.setHeader("Access-Control-Allow-Credentials", "true");
    }
}

package com.activitylog.servlet;

import com.activitylog.dao.UserDAO;
import com.activitylog.model.User;
import com.google.gson.Gson;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

/**
 * UserServlet - REST endpoint for user management.
 * GET /api/users → list all users (admin only)
 */
@WebServlet("/api/users")
public class UserServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();
    private final Gson    gson    = new Gson();

    @Override
    protected void doOptions(HttpServletRequest req, HttpServletResponse res) throws IOException {
        setCorsHeaders(res);
        res.setStatus(HttpServletResponse.SC_OK);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        setCorsHeaders(res);
        res.setContentType("application/json;charset=UTF-8");
        PrintWriter out = res.getWriter();

        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("{\"error\":\"Unauthorized\"}");
            return;
        }

        String role = (String) session.getAttribute("role");
        if (!"ADMIN".equals(role)) {
            res.setStatus(HttpServletResponse.SC_FORBIDDEN);
            out.print("{\"error\":\"Forbidden — Admin access required\"}");
            return;
        }

        List<User> users = userDAO.findAll();
        List<Map<String, Object>> result = new ArrayList<>();
        for (User u : users) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id",          u.getId());
            m.put("username",    u.getUsername());
            m.put("email",       u.getEmail());
            m.put("fullName",    u.getFullName());
            m.put("role",        u.getRole());
            m.put("avatarColor", u.getAvatarColor());
            m.put("initials",    u.getInitials());
            m.put("isActive",    u.isActive());
            m.put("createdAt",   u.getCreatedAt() != null ? u.getCreatedAt().toString() : null);
            m.put("lastLogin",   u.getLastLogin()  != null ? u.getLastLogin().toString()  : "Never");
            result.add(m);
        }

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("users", result);
        response.put("total", result.size());
        out.print(gson.toJson(response));
    }

    private void setCorsHeaders(HttpServletResponse res) {
        res.setHeader("Access-Control-Allow-Origin",  "*");
        res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type");
        res.setHeader("Access-Control-Allow-Credentials", "true");
    }
}

package com.activitylog.model;

import java.time.LocalDateTime;

/**
 * User model representing an application user.
 */
public class User {
    private int id;
    private String username;
    private String email;
    private String passwordHash;
    private String fullName;
    private String role;          // ADMIN | USER
    private String avatarColor;
    private boolean isActive;
    private LocalDateTime createdAt;
    private LocalDateTime lastLogin;

    public User() {}

    public User(int id, String username, String email, String fullName, String role, String avatarColor) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.fullName = fullName;
        this.role = role;
        this.avatarColor = avatarColor;
    }

    // ── Getters & Setters ──────────────────────────────────────────────────
    public int getId()                         { return id; }
    public void setId(int id)                  { this.id = id; }

    public String getUsername()                { return username; }
    public void setUsername(String username)   { this.username = username; }

    public String getEmail()                   { return email; }
    public void setEmail(String email)         { this.email = email; }

    public String getPasswordHash()            { return passwordHash; }
    public void setPasswordHash(String ph)     { this.passwordHash = ph; }

    public String getFullName()                { return fullName; }
    public void setFullName(String n)          { this.fullName = n; }

    public String getRole()                    { return role; }
    public void setRole(String role)           { this.role = role; }

    public String getAvatarColor()             { return avatarColor; }
    public void setAvatarColor(String c)       { this.avatarColor = c; }

    public boolean isActive()                  { return isActive; }
    public void setActive(boolean active)      { this.isActive = active; }

    public LocalDateTime getCreatedAt()        { return createdAt; }
    public void setCreatedAt(LocalDateTime d)  { this.createdAt = d; }

    public LocalDateTime getLastLogin()        { return lastLogin; }
    public void setLastLogin(LocalDateTime d)  { this.lastLogin = d; }

    /** Returns initials from full name for avatar display */
    public String getInitials() {
        if (fullName == null || fullName.isBlank()) return "?";
        String[] parts = fullName.trim().split("\\s+");
        if (parts.length == 1) return parts[0].substring(0, 1).toUpperCase();
        return (parts[0].charAt(0) + "" + parts[parts.length - 1].charAt(0)).toUpperCase();
    }

    @Override
    public String toString() {
        return "User{id=" + id + ", username='" + username + "', role='" + role + "'}";
    }
}

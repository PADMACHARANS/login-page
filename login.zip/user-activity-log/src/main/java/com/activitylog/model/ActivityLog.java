package com.activitylog.model;

import java.time.LocalDateTime;

/**
 * ActivityLog model representing a single tracked user action.
 */
public class ActivityLog {

    public enum ActionType {
        LOGIN, LOGOUT, ACTION, FAILED_LOGIN, PROFILE_UPDATE, DATA_EXPORT, SETTINGS_CHANGE
    }

    private long id;
    private int userId;
    private String username;
    private String fullName;
    private String avatarColor;
    private ActionType actionType;
    private String description;
    private String ipAddress;
    private String userAgent;
    private String sessionId;
    private String metadata;
    private LocalDateTime createdAt;

    public ActivityLog() {}

    public ActivityLog(int userId, ActionType actionType, String description, String ipAddress) {
        this.userId = userId;
        this.actionType = actionType;
        this.description = description;
        this.ipAddress = ipAddress;
    }

    // ── Getters & Setters ──────────────────────────────────────────────────
    public long getId()                           { return id; }
    public void setId(long id)                    { this.id = id; }

    public int getUserId()                        { return userId; }
    public void setUserId(int userId)             { this.userId = userId; }

    public String getUsername()                   { return username; }
    public void setUsername(String username)      { this.username = username; }

    public String getFullName()                   { return fullName; }
    public void setFullName(String fullName)      { this.fullName = fullName; }

    public String getAvatarColor()                { return avatarColor; }
    public void setAvatarColor(String c)          { this.avatarColor = c; }

    public ActionType getActionType()             { return actionType; }
    public void setActionType(ActionType t)       { this.actionType = t; }

    public String getDescription()                { return description; }
    public void setDescription(String desc)       { this.description = desc; }

    public String getIpAddress()                  { return ipAddress; }
    public void setIpAddress(String ip)           { this.ipAddress = ip; }

    public String getUserAgent()                  { return userAgent; }
    public void setUserAgent(String ua)           { this.userAgent = ua; }

    public String getSessionId()                  { return sessionId; }
    public void setSessionId(String s)            { this.sessionId = s; }

    public String getMetadata()                   { return metadata; }
    public void setMetadata(String m)             { this.metadata = m; }

    public LocalDateTime getCreatedAt()           { return createdAt; }
    public void setCreatedAt(LocalDateTime d)     { this.createdAt = d; }

    /** Returns icon key for frontend mapping */
    public String getIcon() {
        if (actionType == null) return "activity";
        return switch (actionType) {
            case LOGIN          -> "log-in";
            case LOGOUT         -> "log-out";
            case FAILED_LOGIN   -> "alert-triangle";
            case PROFILE_UPDATE -> "user-check";
            case DATA_EXPORT    -> "download";
            case SETTINGS_CHANGE-> "settings";
            default             -> "zap";
        };
    }
}

package com.activitylog.dao;

import com.activitylog.model.User;
import com.activitylog.util.DBConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * UserDAO - Data Access Object for User operations via JDBC.
 */
public class UserDAO {

    private static final Logger LOGGER = Logger.getLogger(UserDAO.class.getName());

    private Connection getConn() {
        return DBConnection.getInstance().getConnection();
    }

    // ── Authenticate ───────────────────────────────────────────────────────
    /**
     * Find user by username (caller must verify BCrypt password).
     */
    public User findByUsername(String username) {
        final String SQL = "SELECT * FROM users WHERE username = ? AND is_active = TRUE";
        try (PreparedStatement ps = getConn().prepareStatement(SQL)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            LOGGER.severe("findByUsername error: " + e.getMessage());
        }
        return null;
    }

    // ── Find by ID ─────────────────────────────────────────────────────────
    public User findById(int id) {
        final String SQL = "SELECT * FROM users WHERE id = ?";
        try (PreparedStatement ps = getConn().prepareStatement(SQL)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            LOGGER.severe("findById error: " + e.getMessage());
        }
        return null;
    }

    // ── List All ───────────────────────────────────────────────────────────
    public List<User> findAll() {
        List<User> users = new ArrayList<>();
        final String SQL = "SELECT * FROM users ORDER BY created_at DESC";
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery(SQL)) {
            while (rs.next()) users.add(mapRow(rs));
        } catch (SQLException e) {
            LOGGER.severe("findAll error: " + e.getMessage());
        }
        return users;
    }

    // ── Update Last Login ──────────────────────────────────────────────────
    public void updateLastLogin(int userId) {
        final String SQL = "UPDATE users SET last_login = NOW() WHERE id = ?";
        try (PreparedStatement ps = getConn().prepareStatement(SQL)) {
            ps.setInt(1, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("updateLastLogin error: " + e.getMessage());
        }
    }

    // ── Count Users ────────────────────────────────────────────────────────
    public int countTotal() {
        final String SQL = "SELECT COUNT(*) FROM users WHERE is_active = TRUE";
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery(SQL)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            LOGGER.severe("countTotal error: " + e.getMessage());
        }
        return 0;
    }

    // ── Row Mapper ─────────────────────────────────────────────────────────
    private User mapRow(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId(rs.getInt("id"));
        u.setUsername(rs.getString("username"));
        u.setEmail(rs.getString("email"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setFullName(rs.getString("full_name"));
        u.setRole(rs.getString("role"));
        u.setAvatarColor(rs.getString("avatar_color"));
        u.setActive(rs.getBoolean("is_active"));

        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) u.setCreatedAt(createdAt.toLocalDateTime());

        Timestamp lastLogin = rs.getTimestamp("last_login");
        if (lastLogin != null) u.setLastLogin(lastLogin.toLocalDateTime());

        return u;
    }
}

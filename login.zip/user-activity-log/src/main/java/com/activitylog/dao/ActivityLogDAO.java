package com.activitylog.dao;

import com.activitylog.model.ActivityLog;
import com.activitylog.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * ActivityLogDAO - Data Access Object for activity log operations.
 */
public class ActivityLogDAO {

    private static final Logger LOGGER = Logger.getLogger(ActivityLogDAO.class.getName());

    private Connection getConn() {
        return DBConnection.getInstance().getConnection();
    }

    // ── Insert log entry ───────────────────────────────────────────────────
    public boolean insert(ActivityLog log) {
        final String SQL = """
                INSERT INTO activity_logs
                (user_id, action_type, description, ip_address, user_agent, session_id, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """;
        try (PreparedStatement ps = getConn().prepareStatement(SQL)) {
            ps.setInt(1, log.getUserId());
            ps.setString(2, log.getActionType().name());
            ps.setString(3, log.getDescription());
            ps.setString(4, log.getIpAddress());
            ps.setString(5, log.getUserAgent());
            ps.setString(6, log.getSessionId());
            ps.setString(7, log.getMetadata());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            LOGGER.severe("insert log error: " + e.getMessage());
            return false;
        }
    }

    // ── Find all logs (admin view + optional filter) ───────────────────────
    public List<ActivityLog> findAll(String filterType, int limit, int offset) {
        String SQL = """
                SELECT al.*, u.username, u.full_name, u.avatar_color
                FROM activity_logs al
                JOIN users u ON al.user_id = u.id
                """;
        if (filterType != null && !filterType.isBlank() && !filterType.equals("ALL")) {
            SQL += " WHERE al.action_type = '" + filterType.replaceAll("[^A-Z_]", "") + "'";
        }
        SQL += " ORDER BY al.created_at DESC LIMIT ? OFFSET ?";

        List<ActivityLog> logs = new ArrayList<>();
        try (PreparedStatement ps = getConn().prepareStatement(SQL)) {
            ps.setInt(1, limit);
            ps.setInt(2, offset);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) logs.add(mapRow(rs));
            }
        } catch (SQLException e) {
            LOGGER.severe("findAll error: " + e.getMessage());
        }
        return logs;
    }

    // ── Find logs by user ──────────────────────────────────────────────────
    public List<ActivityLog> findByUser(int userId, int limit) {
        final String SQL = """
                SELECT al.*, u.username, u.full_name, u.avatar_color
                FROM activity_logs al
                JOIN users u ON al.user_id = u.id
                WHERE al.user_id = ?
                ORDER BY al.created_at DESC
                LIMIT ?
                """;
        List<ActivityLog> logs = new ArrayList<>();
        try (PreparedStatement ps = getConn().prepareStatement(SQL)) {
            ps.setInt(1, userId);
            ps.setInt(2, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) logs.add(mapRow(rs));
            }
        } catch (SQLException e) {
            LOGGER.severe("findByUser error: " + e.getMessage());
        }
        return logs;
    }

    // ── Dashboard statistics ───────────────────────────────────────────────
    public Map<String, Object> getStats() {
        Map<String, Object> stats = new HashMap<>();

        // Total log count
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM activity_logs")) {
            if (rs.next()) stats.put("totalLogs", rs.getLong(1));
        } catch (SQLException e) { LOGGER.warning("stats error: " + e.getMessage()); }

        // Today's logins
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT COUNT(*) FROM activity_logs WHERE action_type='LOGIN' AND DATE(created_at) = CURDATE()")) {
            if (rs.next()) stats.put("todayLogins", rs.getLong(1));
        } catch (SQLException e) { LOGGER.warning("stats error: " + e.getMessage()); }

        // Active sessions
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT COUNT(*) FROM user_sessions WHERE is_active = TRUE")) {
            if (rs.next()) stats.put("activeSessions", rs.getLong(1));
        } catch (SQLException e) { LOGGER.warning("stats error: " + e.getMessage()); }

        // Failed logins today
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT COUNT(*) FROM activity_logs WHERE action_type='FAILED_LOGIN' AND DATE(created_at) = CURDATE()")) {
            if (rs.next()) stats.put("failedLogins", rs.getLong(1));
        } catch (SQLException e) { LOGGER.warning("stats error: " + e.getMessage()); }

        // Action type breakdown
        List<Map<String, Object>> breakdown = new ArrayList<>();
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT action_type, COUNT(*) as cnt FROM activity_logs GROUP BY action_type ORDER BY cnt DESC")) {
            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("type", rs.getString("action_type"));
                row.put("count", rs.getLong("cnt"));
                breakdown.add(row);
            }
        } catch (SQLException e) { LOGGER.warning("breakdown error: " + e.getMessage()); }
        stats.put("breakdown", breakdown);

        return stats;
    }

    // ── Total count for pagination ─────────────────────────────────────────
    public int countAll(String filterType) {
        String SQL = "SELECT COUNT(*) FROM activity_logs";
        if (filterType != null && !filterType.isBlank() && !filterType.equals("ALL")) {
            SQL += " WHERE action_type = '" + filterType.replaceAll("[^A-Z_]", "") + "'";
        }
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery(SQL)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { LOGGER.warning("countAll error: " + e.getMessage()); }
        return 0;
    }

    // ── Row Mapper ─────────────────────────────────────────────────────────
    private ActivityLog mapRow(ResultSet rs) throws SQLException {
        ActivityLog al = new ActivityLog();
        al.setId(rs.getLong("id"));
        al.setUserId(rs.getInt("user_id"));
        al.setUsername(rs.getString("username"));
        al.setFullName(rs.getString("full_name"));
        al.setAvatarColor(rs.getString("avatar_color"));
        al.setActionType(ActivityLog.ActionType.valueOf(rs.getString("action_type")));
        al.setDescription(rs.getString("description"));
        al.setIpAddress(rs.getString("ip_address"));
        al.setUserAgent(rs.getString("user_agent"));
        al.setSessionId(rs.getString("session_id"));
        al.setMetadata(rs.getString("metadata"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) al.setCreatedAt(ts.toLocalDateTime());
        return al;
    }
}

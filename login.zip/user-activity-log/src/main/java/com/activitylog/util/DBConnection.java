package com.activitylog.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Logger;

/**
 * DBConnection - Singleton JDBC connection manager.
 * Provides thread-safe database connections using double-checked locking.
 */
public class DBConnection {

    private static final Logger LOGGER = Logger.getLogger(DBConnection.class.getName());

    // ── Database Configuration ─────────────────────────────────────────────
    private static final String DB_URL      = "jdbc:mysql://localhost:3306/activity_log_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String DB_USER     = "root";
    private static final String DB_PASSWORD = "root";   // ← update to your MySQL password
    private static final String DRIVER      = "com.mysql.cj.jdbc.Driver";

    private static volatile DBConnection instance;
    private Connection connection;

    private DBConnection() {
        try {
            Class.forName(DRIVER);
            this.connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            LOGGER.info("✅ Database connection established successfully.");
        } catch (ClassNotFoundException e) {
            LOGGER.severe("❌ MySQL JDBC Driver not found: " + e.getMessage());
            throw new RuntimeException("MySQL driver not found", e);
        } catch (SQLException e) {
            LOGGER.severe("❌ Database connection failed: " + e.getMessage());
            throw new RuntimeException("Database connection failed", e);
        }
    }

    public static DBConnection getInstance() {
        if (instance == null) {
            synchronized (DBConnection.class) {
                if (instance == null) {
                    instance = new DBConnection();
                }
            }
        }
        return instance;
    }

    public Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                LOGGER.warning("⚠️ Connection closed. Re-establishing...");
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            }
        } catch (SQLException e) {
            LOGGER.severe("❌ Failed to re-establish connection: " + e.getMessage());
            throw new RuntimeException("Cannot get database connection", e);
        }
        return connection;
    }

    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                LOGGER.info("Database connection closed.");
            }
        } catch (SQLException e) {
            LOGGER.warning("Error closing connection: " + e.getMessage());
        }
    }
}

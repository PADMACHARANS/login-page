/**
 * AuthService — manages authentication state.
 * Primary: real Servlet API (Tomcat + JDBC + MySQL)
 * Fallback: rich demo mode with mock data (when backend is unavailable)
 */
angular.module('ActivityLogApp')
  .service('AuthService', ['$http', '$q', '$timeout', function ($http, $q, $timeout) {

    var BASE = 'api';
    var _currentUser = null;
    var _demoMode = false;          // flips to true on first network error
    var _demoSession = null;           // persisted in sessionStorage

    // ══ Mock Data ════════════════════════════════════════════════════════════
    var DEMO_USERS = [
      { id: 1, username: 'admin', email: 'admin@activitylog.io', fullName: 'Admin User', role: 'ADMIN', avatarColor: '#FF6B6B', initials: 'AU', isActive: true, lastLogin: '2026-04-06 09:10:00', createdAt: '2025-01-15' },
      { id: 2, username: 'alice', email: 'alice@example.com', fullName: 'Alice Johnson', role: 'USER', avatarColor: '#4ECDC4', initials: 'AJ', isActive: true, lastLogin: '2026-04-06 08:45:00', createdAt: '2025-02-01' },
      { id: 3, username: 'bob', email: 'bob@example.com', fullName: 'Bob Martinez', role: 'USER', avatarColor: '#45B7D1', initials: 'BM', isActive: true, lastLogin: '2026-04-05 17:30:00', createdAt: '2025-02-10' },
      { id: 4, username: 'charlie', email: 'charlie@example.com', fullName: 'Charlie Brown', role: 'USER', avatarColor: '#96CEB4', initials: 'CB', isActive: true, lastLogin: '2026-04-04 14:20:00', createdAt: '2025-03-01' },
      { id: 5, username: 'diana', email: 'diana@example.com', fullName: 'Diana Prince', role: 'USER', avatarColor: '#FFEAA7', initials: 'DP', isActive: true, lastLogin: '2026-04-03 11:00:00', createdAt: '2025-03-15' }
    ];

    var DEMO_LOGS = [
      { id: 1, userId: 1, username: 'admin', fullName: 'Admin User', avatarColor: '#FF6B6B', actionType: 'LOGIN', description: 'Admin User logged in successfully', ipAddress: '192.168.1.1', sessionId: 'sess_a1b2c3d4', icon: 'log-in', createdAt: '2026-04-06 09:10:22' },
      { id: 2, userId: 2, username: 'alice', fullName: 'Alice Johnson', avatarColor: '#4ECDC4', actionType: 'LOGIN', description: 'Alice Johnson logged in successfully', ipAddress: '192.168.1.10', sessionId: 'sess_e5f6g7h8', icon: 'log-in', createdAt: '2026-04-06 08:45:14' },
      { id: 3, userId: 2, username: 'alice', fullName: 'Alice Johnson', avatarColor: '#4ECDC4', actionType: 'ACTION', description: 'Viewed dashboard analytics report', ipAddress: '192.168.1.10', sessionId: 'sess_e5f6g7h8', icon: 'zap', createdAt: '2026-04-06 08:46:01' },
      { id: 4, userId: 2, username: 'alice', fullName: 'Alice Johnson', avatarColor: '#4ECDC4', actionType: 'DATA_EXPORT', description: 'Exported user activity data as CSV', ipAddress: '192.168.1.10', sessionId: 'sess_e5f6g7h8', icon: 'download', createdAt: '2026-04-06 08:48:33' },
      { id: 5, userId: 3, username: 'bob', fullName: 'Bob Martinez', avatarColor: '#45B7D1', actionType: 'LOGIN', description: 'Bob Martinez logged in successfully', ipAddress: '10.0.0.15', sessionId: 'sess_i9j0k1l2', icon: 'log-in', createdAt: '2026-04-05 17:30:55' },
      { id: 6, userId: 3, username: 'bob', fullName: 'Bob Martinez', avatarColor: '#45B7D1', actionType: 'PROFILE_UPDATE', description: 'Updated profile picture and biography', ipAddress: '10.0.0.15', sessionId: 'sess_i9j0k1l2', icon: 'user-check', createdAt: '2026-04-05 17:35:12' },
      { id: 7, userId: 3, username: 'bob', fullName: 'Bob Martinez', avatarColor: '#45B7D1', actionType: 'DATA_EXPORT', description: 'Generated monthly activity summary report', ipAddress: '10.0.0.15', sessionId: 'sess_i9j0k1l2', icon: 'download', createdAt: '2026-04-05 17:40:08' },
      { id: 8, userId: 4, username: 'charlie', fullName: 'Charlie Brown', avatarColor: '#96CEB4', actionType: 'FAILED_LOGIN', description: 'Failed login attempt — incorrect password', ipAddress: '10.0.0.22', sessionId: null, icon: 'alert-triangle', createdAt: '2026-04-04 14:15:30' },
      { id: 9, userId: 4, username: 'charlie', fullName: 'Charlie Brown', avatarColor: '#96CEB4', actionType: 'LOGIN', description: 'Charlie Brown logged in successfully', ipAddress: '10.0.0.22', sessionId: 'sess_m3n4o5p6', icon: 'log-in', createdAt: '2026-04-04 14:20:44' },
      { id: 10, userId: 5, username: 'diana', fullName: 'Diana Prince', avatarColor: '#FFEAA7', actionType: 'LOGIN', description: 'Diana Prince logged in successfully', ipAddress: '172.16.0.5', sessionId: 'sess_q7r8s9t0', icon: 'log-in', createdAt: '2026-04-03 11:00:17' },
      { id: 11, userId: 5, username: 'diana', fullName: 'Diana Prince', avatarColor: '#FFEAA7', actionType: 'SETTINGS_CHANGE', 'description': 'Changed email notification preferences', ipAddress: '172.16.0.5', sessionId: 'sess_q7r8s9t0', icon: 'settings', createdAt: '2026-04-03 11:05:39' },
      { id: 12, userId: 2, username: 'alice', fullName: 'Alice Johnson', avatarColor: '#4ECDC4', actionType: 'LOGOUT', description: 'Alice Johnson logged out', ipAddress: '192.168.1.10', sessionId: 'sess_e5f6g7h8', icon: 'log-out', createdAt: '2026-04-06 09:00:00' },
      { id: 13, userId: 3, username: 'bob', fullName: 'Bob Martinez', avatarColor: '#45B7D1', actionType: 'LOGOUT', description: 'Bob Martinez logged out', ipAddress: '10.0.0.15', sessionId: 'sess_i9j0k1l2', icon: 'log-out', createdAt: '2026-04-05 18:10:22' },
      { id: 14, userId: 1, username: 'admin', fullName: 'Admin User', avatarColor: '#FF6B6B', actionType: 'ACTION', description: 'Reviewed system security audit settings', ipAddress: '192.168.1.1', sessionId: 'sess_a1b2c3d4', icon: 'zap', createdAt: '2026-04-06 09:15:05' },
      { id: 15, userId: 1, username: 'admin', fullName: 'Admin User', avatarColor: '#FF6B6B', actionType: 'PROFILE_UPDATE', description: 'Updated admin profile security credentials', ipAddress: '192.168.1.1', sessionId: 'sess_a1b2c3d4', icon: 'user-check', createdAt: '2026-04-06 09:20:48' }
    ];

    var DEMO_PASSWORDS = { admin: 'password123', alice: 'password123', bob: 'password123', charlie: 'password123', diana: 'password123' };

    // ── Restore demo session from sessionStorage ───────────────────────────
    (function () {
      try {
        var saved = sessionStorage.getItem('_ap_demo_user');
        if (saved) {
          _demoSession = JSON.parse(saved);
          _currentUser = _demoSession;
          _demoMode = true;
        }
      } catch (e) { }
    })();

    function saveDemoSession(user) {
      try { sessionStorage.setItem('_ap_demo_user', JSON.stringify(user)); } catch (e) { }
    }
    function clearDemoSession() {
      try { sessionStorage.removeItem('_ap_demo_user'); } catch (e) { }
    }

    function demoDelay(data) {
      var deferred = $q.defer();
      $timeout(function () { deferred.resolve({ data: data }); }, 280 + Math.random() * 200);
      return deferred.promise;
    }

    // ══ Public API ════════════════════════════════════════════════════════════

    // ── Check existing session ─────────────────────────────────────────────
    this.checkSession = function () {
      var deferred = $q.defer();

      // If already in demo mode with a saved session
      if (_demoMode && _demoSession) {
        $timeout(function () {
          _currentUser = _demoSession;
          deferred.resolve(_demoSession);
        }, 100);
        return deferred.promise;
      }

      $http.get(BASE + '/login', { withCredentials: true })
        .then(function (res) {
          if (res.data && res.data.authenticated) {
            _currentUser = res.data;
            deferred.resolve(res.data);
          } else {
            _currentUser = null;
            deferred.reject(null);
          }
        })
        .catch(function () {
          // Backend not reachable — switch to demo mode
          _demoMode = true;
          if (_demoSession) {
            _currentUser = _demoSession;
            deferred.resolve(_demoSession);
          } else {
            _currentUser = null;
            deferred.reject(null);
          }
        });
      return deferred.promise;
    };

    // ── Login ──────────────────────────────────────────────────────────────
    var self = this;
    this.login = function (username, password) {
      if (_demoMode) {
        var u = DEMO_USERS.find(function (x) { return x.username === username.toLowerCase().trim(); });
        if (u && DEMO_PASSWORDS[u.username] === password) {
          var userData = angular.extend({}, u, {
            success: true, authenticated: true,
            fullName: u.fullName, avatarColor: u.avatarColor
          });
          _currentUser = userData;
          _demoSession = userData;
          saveDemoSession(userData);

          // Add demo login log
          DEMO_LOGS.unshift({
            id: DEMO_LOGS.length + 1, userId: u.id, username: u.username,
            fullName: u.fullName, avatarColor: u.avatarColor,
            actionType: 'LOGIN', description: u.fullName + ' logged in successfully',
            ipAddress: '127.0.0.1', sessionId: 'demo_sess_' + Date.now(),
            icon: 'log-in', createdAt: _now()
          });
          return demoDelay(userData);
        } else {
          var deferred = $q.defer();
          $timeout(function () {
            deferred.reject({ data: { success: false, message: 'Invalid username or password' }, status: 401 });
          }, 400);
          return deferred.promise;
        }
      }

      return $http.post(BASE + '/login', { username: username, password: password }, { withCredentials: true })
        .then(function (res) {
          if (res.data && res.data.success) { _currentUser = res.data; }
          return res.data;
        })
        .catch(function (err) {
          if (!err.status || err.status === 0 || err.status === -1) {
            // Network error — switch to demo and retry
            _demoMode = true;
            return self.login(username, password);
          }
          return $q.reject(err);
        });
    };

    // ── Logout ─────────────────────────────────────────────────────────────
    this.logout = function () {
      if (_demoMode) {
        var u = _currentUser;
        if (u) {
          DEMO_LOGS.unshift({
            id: DEMO_LOGS.length + 1, userId: u.id, username: u.username,
            fullName: u.fullName, avatarColor: u.avatarColor,
            actionType: 'LOGOUT', description: u.fullName + ' logged out',
            ipAddress: '127.0.0.1', sessionId: 'demo_sess_' + Date.now(),
            icon: 'log-out', createdAt: _now()
          });
        }
        _currentUser = null;
        _demoSession = null;
        clearDemoSession();
        return demoDelay({ success: true });
      }

      return $http.post(BASE + '/logout', {}, { withCredentials: true })
        .finally(function () { _currentUser = null; });
    };

    // ── Get current user ───────────────────────────────────────────────────
    this.getCurrentUser = function () { return _currentUser; };

    // ── Fetch activity logs ────────────────────────────────────────────────
    this.getActivities = function (filter, page, size) {
      if (_demoMode) {
        var filtered = DEMO_LOGS.slice();
        if (filter && filter !== 'ALL') {
          filtered = filtered.filter(function (l) { return l.actionType === filter; });
        }
        var p = (page || 1) - 1;
        var s = size || 20;
        var sliced = filtered.slice(p * s, p * s + s);
        return demoDelay({
          logs: sliced, total: filtered.length,
          page: page || 1, size: s,
          totalPages: Math.ceil(filtered.length / s) || 1
        });
      }
      return $http.get(BASE + '/activities', {
        params: { filter: filter || 'ALL', page: page || 1, size: size || 20 },
        withCredentials: true
      }).catch(function () {
        _demoMode = true;
        return self.getActivities(filter, page, size);
      });
    };

    // ── Fetch stats ────────────────────────────────────────────────────────
    this.getStats = function () {
      if (_demoMode) {
        var today = _now().substring(0, 10);
        var breakdown = {};
        DEMO_LOGS.forEach(function (l) {
          breakdown[l.actionType] = (breakdown[l.actionType] || 0) + 1;
        });
        var bdArr = Object.keys(breakdown).map(function (k) {
          return { type: k, count: breakdown[k] };
        }).sort(function (a, b) { return b.count - a.count; });

        return demoDelay({
          totalLogs: DEMO_LOGS.length,
          todayLogins: DEMO_LOGS.filter(function (l) { return l.actionType === 'LOGIN' && l.createdAt.startsWith(today); }).length,
          activeSessions: 2,
          failedLogins: DEMO_LOGS.filter(function (l) { return l.actionType === 'FAILED_LOGIN' && l.createdAt.startsWith(today); }).length,
          breakdown: bdArr
        });
      }
      return $http.get(BASE + '/activities/stats', { withCredentials: true })
        .catch(function () { _demoMode = true; return self.getStats(); });
    };

    // ── Post a new action ──────────────────────────────────────────────────
    this.logAction = function (actionType, description) {
      if (_demoMode && _currentUser) {
        DEMO_LOGS.unshift({
          id: DEMO_LOGS.length + 1, userId: _currentUser.id,
          username: _currentUser.username, fullName: _currentUser.fullName,
          avatarColor: _currentUser.avatarColor,
          actionType: actionType, description: description,
          ipAddress: '127.0.0.1', sessionId: 'demo_sess_live',
          icon: 'zap', createdAt: _now()
        });
        return demoDelay({ success: true, message: 'Activity logged (demo)' });
      }
      return $http.post(BASE + '/activities', { actionType: actionType, description: description }, { withCredentials: true })
        .catch(function () { _demoMode = true; return self.logAction(actionType, description); });
    };

    // ── Fetch users (admin) ────────────────────────────────────────────────
    this.getUsers = function () {
      if (_demoMode) {
        return demoDelay({ users: DEMO_USERS, total: DEMO_USERS.length });
      }
      return $http.get(BASE + '/users', { withCredentials: true })
        .catch(function () { _demoMode = true; return self.getUsers(); });
    };

    // ── isDemoMode ─────────────────────────────────────────────────────────
    this.isDemoMode = function () { return _demoMode; };

    // ── Helpers ────────────────────────────────────────────────────────────
    function _now() {
      var d = new Date();
      return d.getFullYear()
        + '-' + _pad(d.getMonth() + 1)
        + '-' + _pad(d.getDate())
        + ' ' + _pad(d.getHours())
        + ':' + _pad(d.getMinutes())
        + ':' + _pad(d.getSeconds());
    }
    function _pad(n) { return n < 10 ? '0' + n : n; }

  }]);

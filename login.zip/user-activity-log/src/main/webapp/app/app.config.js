/**
 * App configuration — Routes & Filters
 */
angular.module('ActivityLogApp')
  .config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {

    $routeProvider
      .when('/login', {
        templateUrl: 'login.html',
        resolve: {
          redirectIfLoggedIn: ['AuthService', '$location', function(AuthService, $location) {
            return AuthService.checkSession().then(function(user) {
              if (user) $location.path('/dashboard');
            }).catch(function() {
              // Not logged in — stay on login page
            });
          }]
        }
      })
      .when('/dashboard', {
        templateUrl: 'dashboard.html',
        resolve: {
          currentUser: ['AuthService', '$location', function(AuthService, $location) {
            return AuthService.checkSession().then(function(user) {
              if (!user) $location.path('/login');
              return user;
            }).catch(function() {
              $location.path('/login');
            });
          }]
        }
      })
      .otherwise({ redirectTo: '/login' });

    // Use hash-based routing for WAR compatibility
    $locationProvider.hashPrefix('!');
  }])

  // ── Custom Filter: capitalize ────────────────────────────────────────────
  .filter('capitalize', function() {
    return function(input) {
      if (!input) return '';
      return input.charAt(0).toUpperCase() + input.slice(1).toLowerCase();
    };
  });

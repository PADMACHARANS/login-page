/**
 * ActivityLogApp — AngularJS Application Module
 * Requires: ngRoute, ngAnimate
 */
angular.module('ActivityLogApp', ['ngRoute', 'ngAnimate']);

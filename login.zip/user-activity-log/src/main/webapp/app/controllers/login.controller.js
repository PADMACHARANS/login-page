/**
 * LoginController — handles login page logic.
 */
angular.module('ActivityLogApp')
  .controller('LoginController', ['$scope', '$location', 'AuthService', function($scope, $location, AuthService) {
    var vm = this;

    vm.credentials  = { username: '', password: '' };
    vm.errors       = {};
    vm.serverError  = '';
    vm.loading      = false;
    vm.showPassword = false;
    vm.shakeForm    = false;

    // ── Fill demo credentials ──────────────────────────────────────────────
    vm.fillDemo = function(username) {
      vm.credentials.username = username;
      vm.credentials.password = 'password123';
      vm.errors       = {};
      vm.serverError  = '';
    };

    vm.clearError = function(field) {
      delete vm.errors[field];
      vm.serverError = '';
    };

    // ── Login ──────────────────────────────────────────────────────────────
    vm.login = function() {
      vm.errors      = {};
      vm.serverError = '';

      // Client-side validation
      if (!vm.credentials.username) vm.errors.username = 'Username is required';
      if (!vm.credentials.password) vm.errors.password = 'Password is required';
      if (Object.keys(vm.errors).length) return;

      vm.loading = true;
      AuthService.login(vm.credentials.username, vm.credentials.password)
        .then(function(data) {
          if (data && data.success) {
            showToast('Welcome back, ' + data.fullName + '! 👋', 'success');
            $location.path('/dashboard');
          } else {
            vm.serverError = data.message || 'Login failed. Please try again.';
            triggerShake();
          }
        })
        .catch(function(err) {
          vm.serverError = (err.data && err.data.message)
            ? err.data.message
            : 'Invalid credentials. Please try again.';
          triggerShake();
        })
        .finally(function() {
          vm.loading = false;
        });
    };

    function triggerShake() {
      vm.shakeForm = true;
      setTimeout(function() { $scope.$apply(function() { vm.shakeForm = false; }); }, 600);
    }

    // ── Toast helper ───────────────────────────────────────────────────────
    function showToast(msg, type) {
      var container = document.getElementById('toast-container');
      if (!container) return;
      var toast = document.createElement('div');
      toast.className = 'toast toast-' + (type || 'info');
      toast.textContent = msg;
      container.appendChild(toast);
      setTimeout(function() { toast.classList.add('toast-show'); }, 10);
      setTimeout(function() {
        toast.classList.remove('toast-show');
        setTimeout(function() { container.removeChild(toast); }, 300);
      }, 3000);
    }
  }]);

/**
 * DashboardController — main dashboard with stats, logs, users, and simulation.
 */
angular.module('ActivityLogApp')
  .controller('DashboardController', [
    '$scope', '$location', '$interval', '$timeout', 'AuthService',
    function($scope, $location, $interval, $timeout, AuthService) {
      var vm = this;

      // ── State ────────────────────────────────────────────────────────────
      vm.currentUser      = AuthService.getCurrentUser() || {};
      vm.activeView       = 'overview';
      vm.sidebarCollapsed = false;

      vm.logs             = [];
      vm.recentLogs       = [];
      vm.users            = [];
      vm.stats            = {};
      vm.statCards        = [];

      vm.logFilter        = 'ALL';
      vm.searchQuery      = '';
      vm.currentPage      = 1;
      vm.pageSize         = 20;
      vm.totalPages       = 1;
      vm.logsLoading      = false;
      vm.refreshing       = false;

      vm.liveRefresh      = true;
      vm.liveInterval     = null;

      vm.simAction        = 'ACTION';
      vm.simDescription   = '';
      vm.simulating       = false;
      vm.simLogs          = [];

      vm.filterOptions    = ['ALL', 'LOGIN', 'LOGOUT', 'ACTION', 'FAILED_LOGIN', 'PROFILE_UPDATE', 'DATA_EXPORT', 'SETTINGS_CHANGE'];

      // Check if running in demo mode (no backend)
      vm.inDemoMode = AuthService.isDemoMode();

      vm.presets = [
        { emoji: '📊', label: 'Viewed Analytics',     type: 'ACTION',          desc: 'Viewed dashboard analytics report'      },
        { emoji: '📥', label: 'Export CSV',            type: 'DATA_EXPORT',     desc: 'Exported activity data as CSV'           },
        { emoji: '⚙️', label: 'Changed Settings',     type: 'SETTINGS_CHANGE', desc: 'Modified notification preferences'       },
        { emoji: '👤', label: 'Updated Profile',      type: 'PROFILE_UPDATE',  desc: 'Updated profile picture and bio'         },
        { emoji: '🔍', label: 'Searched Records',     type: 'ACTION',          desc: 'Performed advanced data search query'    },
        { emoji: '📋', label: 'Generated Report',     type: 'DATA_EXPORT',     desc: 'Generated monthly activity summary PDF'  },
      ];

      // ── Init ─────────────────────────────────────────────────────────────
      (function init() {
        loadStats();
        loadLogs();
        if (vm.currentUser.role === 'ADMIN') loadUsers();
        startLiveRefresh();
        feather && feather.replace && $timeout(function() { feather.replace(); }, 100);
      })();

      // ── Navigation ───────────────────────────────────────────────────────
      vm.setView = function(view) {
        vm.activeView = view;
        if (view === 'logs')    loadLogs();
        if (view === 'users')   loadUsers();
        if (view === 'overview') loadStats();
        $timeout(function() { feather && feather.replace(); }, 100);
      };

      // ── Load Stats ───────────────────────────────────────────────────────
      function loadStats() {
        AuthService.getStats()
          .then(function(res) {
            vm.stats = res.data;
            buildStatCards(res.data);
          })
          .catch(handleAuthError);
      }

      function buildStatCards(data) {
        vm.statCards = [
          {
            label: 'Total Logs',
            value: data.totalLogs || 0,
            delta: '+12% from last week',
            deltaPositive: true,
            color: '#a855f7',
            icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>'
          },
          {
            label: "Today's Logins",
            value: data.todayLogins || 0,
            delta: '+3 since morning',
            deltaPositive: true,
            color: '#06b6d4',
            icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>'
          },
          {
            label: 'Active Sessions',
            value: data.activeSessions || 0,
            delta: '2 sessions active',
            deltaPositive: true,
            color: '#10b981',
            icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>'
          },
          {
            label: 'Failed Logins',
            value: data.failedLogins || 0,
            delta: '0 in last hour',
            deltaPositive: false,
            color: '#ef4444',
            icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>'
          }
        ];
      }

      // ── Load Logs ────────────────────────────────────────────────────────
      function loadLogs() {
        vm.logsLoading = true;
        AuthService.getActivities(vm.logFilter, vm.currentPage, vm.pageSize)
          .then(function(res) {
            vm.logs       = res.data.logs || [];
            vm.recentLogs = vm.logs.slice(0, 10);
            vm.totalPages = res.data.totalPages || 1;
          })
          .catch(handleAuthError)
          .finally(function() { vm.logsLoading = false; });
      }

      // ── Load Users ───────────────────────────────────────────────────────
      function loadUsers() {
        AuthService.getUsers()
          .then(function(res) { vm.users = res.data.users || []; })
          .catch(handleAuthError);
      }

      // ── Filters & Pagination ─────────────────────────────────────────────
      vm.applyFilter = function(f) {
        vm.logFilter   = f;
        vm.currentPage = 1;
        loadLogs();
      };

      vm.onSearch = function() {
        // Client-side filter via ng-filter in template
      };

      vm.goToPage = function(page) {
        if (page < 1 || page > vm.totalPages) return;
        vm.currentPage = page;
        loadLogs();
      };

      // ── Live Refresh ─────────────────────────────────────────────────────
      function startLiveRefresh() {
        vm.liveInterval = $interval(function() {
          if (vm.liveRefresh) {
            loadStats();
            if (vm.activeView === 'logs' || vm.activeView === 'overview') loadLogs();
          }
        }, 10000); // every 10 seconds
      }

      vm.toggleLiveRefresh = function() {
        vm.liveRefresh = !vm.liveRefresh;
        showToast(vm.liveRefresh ? '▶ Live refresh enabled' : '⏸ Live refresh paused', 'info');
      };

      vm.refreshData = function() {
        vm.refreshing = true;
        loadStats();
        loadLogs();
        $timeout(function() { vm.refreshing = false; }, 800);
        showToast('Data refreshed', 'success');
      };

      // ── Simulate Action ──────────────────────────────────────────────────
      vm.applyPreset = function(preset) {
        vm.simAction      = preset.type;
        vm.simDescription = preset.desc;
      };

      vm.simulateAction = function() {
        var desc = vm.simDescription || 'Simulated ' + vm.simAction.toLowerCase().replace('_', ' ');
        vm.simulating = true;

        AuthService.logAction(vm.simAction, desc)
          .then(function(res) {
            var entry = {
              time: new Date().toLocaleTimeString(),
              type: vm.simAction,
              desc: desc,
              ok:   res.data && res.data.success
            };
            vm.simLogs.unshift(entry);
            showToast('Action logged: ' + vm.simAction, 'success');
            loadLogs();
            loadStats();
          })
          .catch(function() {
            vm.simLogs.unshift({ time: new Date().toLocaleTimeString(), type: vm.simAction, desc: desc, ok: false });
            showToast('Failed to log action', 'error');
          })
          .finally(function() { vm.simulating = false; });
      };

      // ── Logout ───────────────────────────────────────────────────────────
      vm.logout = function() {
        AuthService.logout().finally(function() {
          $location.path('/login');
          showToast('You have been logged out.', 'info');
        });
      };

      // ── Cleanup ──────────────────────────────────────────────────────────
      $scope.$on('$destroy', function() {
        if (vm.liveInterval) $interval.cancel(vm.liveInterval);
      });

      // ── Utility Methods ──────────────────────────────────────────────────
      vm.getInitials = function(fullName) {
        if (!fullName) return '?';
        var parts = fullName.trim().split(' ');
        if (parts.length === 1) return parts[0][0].toUpperCase();
        return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
      };

      vm.timeAgo = function(dateStr) {
        if (!dateStr) return '';
        var date  = new Date(dateStr.replace(' ', 'T'));
        var diff  = (Date.now() - date.getTime()) / 1000;
        if (diff < 60)   return 'just now';
        if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
        if (diff < 86400)return Math.floor(diff / 3600) + 'h ago';
        return Math.floor(diff / 86400) + 'd ago';
      };

      vm.getPercent = function(count) {
        if (!vm.stats.breakdown || vm.stats.breakdown.length === 0) return 0;
        var max = vm.stats.breakdown[0].count;
        return max ? Math.round((count / max) * 100) : 0;
      };

      vm.getActionColor = function(type) {
        var colors = {
          LOGIN:           '#06b6d4',
          LOGOUT:          '#f97316',
          ACTION:          '#a855f7',
          FAILED_LOGIN:    '#ef4444',
          PROFILE_UPDATE:  '#10b981',
          DATA_EXPORT:     '#3b82f6',
          SETTINGS_CHANGE: '#f59e0b'
        };
        return colors[type] || '#6b7280';
      };

      // ── Auth error handler ────────────────────────────────────────────────
      function handleAuthError(err) {
        if (err && (err.status === 401 || err.status === 403)) {
          $location.path('/login');
        }
      }

      // ── Toast helper ──────────────────────────────────────────────────────
      function showToast(msg, type) {
        var container = document.getElementById('toast-container');
        if (!container) return;
        var toast = document.createElement('div');
        toast.className   = 'toast toast-' + (type || 'info');
        toast.textContent = msg;
        container.appendChild(toast);
        setTimeout(function() { toast.classList.add('toast-show'); }, 10);
        setTimeout(function() {
          toast.classList.remove('toast-show');
          setTimeout(function() { if (container.contains(toast)) container.removeChild(toast); }, 300);
        }, 3500);
      }
    }
  ]);

-- ============================================
--  User Activity Log System - Database Schema
-- ============================================

CREATE DATABASE IF NOT EXISTS activity_log_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE activity_log_db;

-- ─────────────────────────────────────────────
-- Users Table
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id           INT PRIMARY KEY AUTO_INCREMENT,
    username     VARCHAR(50)  NOT NULL UNIQUE,
    email        VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name    VARCHAR(100) NOT NULL,
    role         ENUM('ADMIN', 'USER') DEFAULT 'USER',
    avatar_color VARCHAR(10)  DEFAULT '#6C63FF',
    is_active    BOOLEAN      DEFAULT TRUE,
    created_at   DATETIME     DEFAULT CURRENT_TIMESTAMP,
    last_login   DATETIME     NULL
);

-- ─────────────────────────────────────────────
-- Activity Logs Table
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS activity_logs (
    id           BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id      INT          NOT NULL,
    action_type  ENUM('LOGIN', 'LOGOUT', 'ACTION', 'FAILED_LOGIN', 'PROFILE_UPDATE', 'DATA_EXPORT', 'SETTINGS_CHANGE') NOT NULL,
    description  VARCHAR(500) NOT NULL,
    ip_address   VARCHAR(45)  NULL,
    user_agent   VARCHAR(255) NULL,
    session_id   VARCHAR(100) NULL,
    metadata     JSON         NULL,
    created_at   DATETIME     DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id   (user_id),
    INDEX idx_action    (action_type),
    INDEX idx_created   (created_at)
);

-- ─────────────────────────────────────────────
-- Sessions Table
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_sessions (
    id            VARCHAR(100) PRIMARY KEY,
    user_id       INT          NOT NULL,
    login_at      DATETIME     DEFAULT CURRENT_TIMESTAMP,
    logout_at     DATETIME     NULL,
    ip_address    VARCHAR(45)  NULL,
    is_active     BOOLEAN      DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ─────────────────────────────────────────────
-- Seed Data  (passwords are BCrypt of "password123")
-- ─────────────────────────────────────────────
INSERT IGNORE INTO users (username, email, password_hash, full_name, role, avatar_color) VALUES
('admin',   'admin@activitylog.io',  '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Admin User',     'ADMIN', '#FF6B6B'),
('alice',   'alice@example.com',     '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Alice Johnson',   'USER',  '#4ECDC4'),
('bob',     'bob@example.com',       '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Bob Martinez',    'USER',  '#45B7D1'),
('charlie', 'charlie@example.com',   '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Charlie Brown',   'USER',  '#96CEB4'),
('diana',   'diana@example.com',     '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Diana Prince',    'USER',  '#FFEAA7');

-- Sample activity logs
INSERT IGNORE INTO activity_logs (user_id, action_type, description, ip_address, session_id) VALUES
(1, 'LOGIN',          'Admin logged in successfully',        '192.168.1.1',   'sess_001'),
(2, 'LOGIN',          'Alice logged in successfully',        '192.168.1.10',  'sess_002'),
(2, 'ACTION',         'Viewed dashboard analytics',          '192.168.1.10',  'sess_002'),
(2, 'ACTION',         'Exported user report as CSV',         '192.168.1.10',  'sess_002'),
(3, 'LOGIN',          'Bob logged in successfully',          '10.0.0.15',     'sess_003'),
(3, 'ACTION',         'Updated profile information',         '10.0.0.15',     'sess_003'),
(3, 'DATA_EXPORT',    'Exported activity logs',              '10.0.0.15',     'sess_003'),
(4, 'FAILED_LOGIN',   'Failed login attempt — wrong password','10.0.0.22',    NULL),
(4, 'LOGIN',          'Charlie logged in successfully',      '10.0.0.22',     'sess_004'),
(5, 'LOGIN',          'Diana logged in successfully',        '172.16.0.5',    'sess_005'),
(5, 'SETTINGS_CHANGE','Changed notification preferences',    '172.16.0.5',    'sess_005'),
(2, 'LOGOUT',         'Alice logged out',                    '192.168.1.10',  'sess_002'),
(3, 'LOGOUT',         'Bob logged out',                      '10.0.0.15',     'sess_003'),
(1, 'ACTION',         'Reviewed system security settings',   '192.168.1.1',   'sess_001'),
(1, 'PROFILE_UPDATE', 'Updated admin profile picture',       '192.168.1.1',   'sess_001');
